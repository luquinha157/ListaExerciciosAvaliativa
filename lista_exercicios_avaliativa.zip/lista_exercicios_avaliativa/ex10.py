num = input('Digite um valor: ')
if num < 0:
    print (num * -1)
elif num > 10:
    num2 = input('Digite outro valor: ')
    print (num - num2)
else:
    print (num/5.0)
teste = []
    
msg = "EXERCICIO1 - VETOR"

def troca(vetor):
    for i in range(3):
        if vetor[i] >= 0:
            vetor[i] = 1
        else:
            vetor[i] = 0
    return vetor

vetor = [0]*3
for i in range(3):
    vetor[i] = input('Digite um valor: ')
print(vetor)
troca(vetor)
print(vetor)